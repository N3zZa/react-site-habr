import React from 'react'

function SignUpFormAdvertiser() {
  return (
    <form action="">
      <input type="text" placeholder="Ваше Имя" />
      <input type="text" placeholder="Ваш Емайл" />
      <input type="text" placeholder="Никнейм телеграм" />
      <input type="text" placeholder="Компания" />
      <input type="text" placeholder="Кратко про кампании" />
      <button>Продолжить</button>
    </form>
  );
}
export default  SignUpFormAdvertiser
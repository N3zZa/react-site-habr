import React from 'react'

export default function SignUpFormOwner() {
  return (
    <form action="">
      <input type="text" placeholder="Ваше Имя" />
      <input type="text" placeholder="Ваш Емайл" />
      <input type="text" placeholder="Никнейм телеграм" />
      <input type="text" placeholder="URL канала" />
      <button>Продолжить</button>
    </form>
  );
}
